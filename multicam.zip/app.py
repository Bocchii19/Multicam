import os
import tkinter as tk
import cv2
from ultralytics import YOLO
from PIL import Image, ImageTk

# --- Base directory ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")

# --- Load models ---
person_detect_model = YOLO(os.path.join(MODEL_DIR, "/home/minhduc/Code/YOLO/person_detection.pt"))
person_segment_model = YOLO(os.path.join(MODEL_DIR, "/home/minhduc/Code/YOLO/person_segmentation.pt"))
pose_estimate_model = YOLO(os.path.join(MODEL_DIR, "/home/minhduc/Code/YOLO/pose.pt"))  # Model 4

face_detect_model = cv2.FaceDetectorYN.create(
    os.path.join(MODEL_DIR, "/home/minhduc/Code/YOLO/face_detection_yunet_2023mar.onnx"),
    "",
    (320, 320),
    0.9,
    0.3,
    5000
)

# --- Global ---
cap = cv2.VideoCapture(0)
current_model = None

# --- Detection logic ---
def update_frame():
    global current_model
    if not cap.isOpened():
        return

    ret, frame = cap.read()
    if not ret:
        return

    if current_model == "model1":
        results = person_detect_model(frame, verbose=False)
        frame = results[0].plot()

    elif current_model == "model2":
        h, w, _ = frame.shape
        face_detect_model.setInputSize((w, h))
        _, faces = face_detect_model.detect(frame)
        if faces is not None:
            for face in faces:
                x, y, w, h = face[0:4].astype(int)
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

    elif current_model == "model3":
        results = person_segment_model(frame, verbose=False)
        frame = results[0].plot()

    elif current_model == "model4":
        results = pose_estimate_model(frame, verbose=False)
        frame = results[0].plot()

    # Convert frame to ImageTk
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img = Image.fromarray(rgb)
    imgtk = ImageTk.PhotoImage(image=img)
    video_label.imgtk = imgtk
    video_label.configure(image=imgtk)

    # Loop
    video_label.after(10, update_frame)

# --- GUI ---
root = tk.Tk()
root.title("MULTI CAMERA AI")
root.geometry("1280x720")

title_label = tk.Label(root, text="Demo YOLO Detection", font=("Arial", 18, "bold"))
title_label.pack(pady=10)

# Video display - to lớn hơn
video_label = tk.Label(root, width=1280, height=480)
video_label.pack()

# Status
status_label = tk.Label(root, text="Chưa chọn model", font=("Arial", 14), fg="red")
status_label.pack(pady=10)

# --- Button handlers ---
def run_person_detect():
    global current_model
    current_model = "model1"
    status_label.config(text="Đang chạy Model 1 (Person Detection)", fg="green")

def run_face_detect():
    global current_model
    current_model = "model2"
    status_label.config(text="Đang chạy Model 2 (Face Detection)", fg="blue")

def run_person_segment():
    global current_model
    current_model = "model3"
    status_label.config(text="Đang chạy Model 3 (Person Segmentation)", fg="red")

def run_pose_estimate():
    global current_model
    current_model = "model4"
    status_label.config(text="Đang chạy Model 4 (Pose Estimation)", fg="purple")

# --- Frame chứa các nút ---
button_frame = tk.Frame(root)
button_frame.pack(pady=5)

# --- Các nút hiển thị ngang 1 dòng 4 cột ---
btn_style = {
    "font": ("Arial", 13, "bold"),
    "width": 25,
    "height": 2,
    "padx": 5,
    "pady": 5
}

button_model1 = tk.Button(button_frame, text="Person Detection", bg="#4CAF50", fg="white",
                          command=run_person_detect, **btn_style)
button_model1.grid(row=0, column=0)

button_model2 = tk.Button(button_frame, text="Face Detection (YuNet)", bg="#2196F3", fg="white",
                          command=run_face_detect, **btn_style)
button_model2.grid(row=0, column=1)

button_model3 = tk.Button(button_frame, text="Person Segmentation", bg="#F32121", fg="white",
                          command=run_person_segment, **btn_style)
button_model3.grid(row=0, column=2)

button_model4 = tk.Button(button_frame, text="Pose Estimation", bg="#9C27B0", fg="white",
                          command=run_pose_estimate, **btn_style)
button_model4.grid(row=0, column=3)

# --- Start detection ---
update_frame()
root.mainloop()
cap.release()
